# Code Readme

This folder contains the individual codebases for each FOB. Each file is the same; the only differences are the FOB IDs and the lists of the other two FOB IP addresses. `listIP.txt` contains a list of each FOB and their respective IPs. All communication used port 64209.